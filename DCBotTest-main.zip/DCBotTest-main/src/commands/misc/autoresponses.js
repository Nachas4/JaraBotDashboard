const {
  Client,
  GuildMember
} = require("discord.js");
const db = require('../../database');
/**
   *
   * @param {Client} client
   * @param {GuildMember} member
   */
module.exports = {
  name: 'autoresponses',
  description: 'list of autoresponses!',
  // devOnly: Boolean,
  // testOnly: Boolean,
  // options: Object[],
  // deleted: Boolean,

  callback: async (client, interaction) => {
    let guild = interaction.guild;
    if (!guild) return;
    await interaction.deferReply();
    let findGuildForeignKey = await db.findOne(
      "dc_guilds",
      "guild_id",
      guild.id
    );
    const reply = await interaction.fetchReply();
    const responses = await db.findMany('auto_responses', 'dc_guild_id', findGuildForeignKey.id)
    let list = '';
    for(respons of responses){
      list += `${respons.respond_to}\n`
    }


    interaction.editReply(
      `list of responses:\n${list}`
    );
  },
};