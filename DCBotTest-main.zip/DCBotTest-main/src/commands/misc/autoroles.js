const {
    Client,
    GuildMember
  } = require("discord.js");
  const db = require('../../database');
  /**
     *
     * @param {Client} client
     * @param {GuildMember} member
     */
  module.exports = {
    name: 'autoroles',
    description: 'list of autoroles!',
    // devOnly: Boolean,
    // testOnly: Boolean,
    // options: Object[],
    // deleted: Boolean,
  
    callback: async (client, interaction) => {
      let guild = interaction.guild;
      if (!guild) return;
      await interaction.deferReply();
      let findGuildForeignKey = await db.findOne(
        "dc_guilds",
        "guild_id",
        guild.id
      );
      const reply = await interaction.fetchReply();
      const roles = await db.findMany('auto_roles', 'dc_guild_id', findGuildForeignKey.id)
      let list = '';
      for(role of roles){
        list += `${interaction.guild.roles.cache.get(role.role_id)}\n`
      }
  
  
      interaction.editReply(
        `list of autoroles:\n${list}`
      );
    },
  };