const {
    Client,
    GuildMember
  } = require("discord.js");
  const db = require('../../database');
  /**
     *
     * @param {Client} client
     * @param {GuildMember} member
     */
  module.exports = {
    name: 'modchannels',
    description: 'list of modchannels!',
    // devOnly: Boolean,
    // testOnly: Boolean,
    // options: Object[],
    // deleted: Boolean,
  
    callback: async (client, interaction) => {
      let guild = interaction.guild;
      if (!guild) return;
      await interaction.deferReply();
      let findGuildForeignKey = await db.findOne(
        "dc_guilds",
        "guild_id",
        guild.id
      );
      const reply = await interaction.fetchReply();
      const modchannels = await db.findOne('mod_message_channels', 'dc_guild_id', findGuildForeignKey.id)
      let list = '';
    list += `${client.channels.cache.get(modchannels.ban)}\n`
    list += `${client.channels.cache.get(modchannels.kick)}\n`
    list += `${client.channels.cache.get(modchannels.timeout)}\n`
    list += `${client.channels.cache.get(modchannels.blacklist)}\n`
  
      interaction.editReply(
        `list of modchannels:\n${list}`
      );
    },
  };