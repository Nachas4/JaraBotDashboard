const {
    Client,
    GuildMember
  } = require("discord.js");
  const db = require('../../database');
  /**
     *
     * @param {Client} client
     * @param {GuildMember} member
     */
  module.exports = {
    name: 'pickups',
    description: 'list of pickups',
    // devOnly: Boolean,
    // testOnly: Boolean,
    // options: Object[],
    // deleted: Boolean,
  
    callback: async (client, interaction) => {
      let guild = interaction.guild;
      if (!guild) return;
      await interaction.deferReply();
      let findGuildForeignKey = await db.findOne(
        "dc_guilds",
        "guild_id",
        guild.id
      );
      const reply = await interaction.fetchReply();
      const pickups = await db.findMany('pickup_lines', 'dc_guild_id', findGuildForeignKey.id)
      let list = '';
      for(pickup of pickups){
        list += `${pickup.line}\n`
      }


      interaction.editReply(
        `list of pickups:\n${list}`
      );
    },
  };