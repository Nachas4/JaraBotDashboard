const {
    Client,
    GuildMember
  } = require("discord.js");
  const db = require('../../database');
  /**
     *
     * @param {Client} client
     * @param {GuildMember} member
     */
  module.exports = {
    name: 'quote',
    description: 'tells a quote',
    // devOnly: Boolean,
    // testOnly: Boolean,
    // options: Object[],
    // deleted: Boolean,
  
    callback: async (client, interaction) => {
      let guild = interaction.guild;
      if (!guild) return;
      await interaction.deferReply();
      let findGuildForeignKey = await db.findOne(
        "dc_guilds",
        "guild_id",
        guild.id
      );
      const reply = await interaction.fetchReply();
      const roles = await db.findMany('quotes', 'dc_guild_id', findGuildForeignKey.id)
      let count = roles.length;
      function getRandomInt(max) {
        return Math.floor(Math.random() * max);
      }
      interaction.editReply(
        `your quote:\n${roles[getRandomInt(count)].content}`
      );
    },
  };