const {
    Client,
    GuildMember
  } = require("discord.js");
  const db = require('../../database');
  /**
     *
     * @param {Client} client
     * @param {GuildMember} member
     */
  module.exports = {
    name: 'quotes',
    description: 'list of quotes',
    // devOnly: Boolean,
    // testOnly: Boolean,
    // options: Object[],
    // deleted: Boolean,
  
    callback: async (client, interaction) => {
      let guild = interaction.guild;
      if (!guild) return;
      await interaction.deferReply();
      let findGuildForeignKey = await db.findOne(
        "dc_guilds",
        "guild_id",
        guild.id
      );
      const reply = await interaction.fetchReply();
      const quotes = await db.findMany('quotes', 'dc_guild_id', findGuildForeignKey.id)
      let list = '';
      for(quote of quotes){
        list += `${quote.content}\n`
      }


      interaction.editReply(
        `list of quotes:\n${list}`
      );
    },
  };