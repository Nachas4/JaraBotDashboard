const {
    Client,
    Interaction,
    ApplicationCommandOptionType,
    EmbedBuilder,
    ButtonBuilder,
    ActionRowBuilder,
    ButtonStyle,
    PermissionFlagsBits,
  } = require("discord.js");
  const choices = [
    { name: "Rock", emoji: "🪨", beats: "Scissors" },
    { name: "Paper", emoji: "📄", beats: "Rock" },
    { name: "Scissors", emoji: "✂️", beats: "Paper" },
  ];
  
  const ms = require("ms");
  
  module.exports = {
    /**
     *
     * @param {Client} client
     * @param {Interaction} interaction
     */
  
    callback: async (client, interaction) => {
      const targetUser = interaction.options.get("target-user");
      await interaction.deferReply();
  
      if (!targetUser) {
        await interaction.editReply("That user doesn't exist in this server.");
        return;
      }
      if (targetUser.user.bot) {
        await interaction.editReply("You cannot play against a bot.");
        return;
      }
   if (targetUser.user == interaction.user) {
    await interaction.editReply("You cannot play against yourself.");
        return;
  }
      const embed = new EmbedBuilder()
        .setTitle("Rock Paper Scissors")
        .setDescription(`It's currently <@${targetUser['user'].id}>'s turn.`)
        .setColor("Red")
        .setTimestamp(new Date());
  
      const buttons = choices.map((choice) => {
        return new ButtonBuilder()
          .setCustomId(choice.name)
          .setLabel(choice.name)
          .setStyle(ButtonStyle.Primary)
          .setEmoji(choice.emoji);
      });
  
      const row = new ActionRowBuilder().addComponents(buttons);
  
      const reply = await interaction.editReply({
          content: `<@${targetUser['user'].id}>, You have been challenged to a game of Rock Paper Scissors, by ${interaction.user}. To start playing, click one of the buttons below.`,
          embeds: [embed],
          components: [row],
      });
  
      const targetUserInteraction = await reply.awaitMessageComponent({
          filter: (i) => i.user.id === targetUser['user'].id,
        
      }).catch(async (error) => {
          embed.setDescription(`Game over. <@${targetUser['user'].id}> did not respond in time.`);
          await reply.edit({ embeds: [embed], components: [] });
      });
  
      if (!targetUserInteraction) return;
  
      const targetUserChoice = choices.find(
          (choice) => choice.name === targetUserInteraction.customId,
      );
  
      await targetUserInteraction.reply({
          content: `You picked ${targetUserChoice.name + targetUserChoice.emoji}`,
          ephemeral: true,
      });
  
      //Edit embed with the updated user turn
      embed.setDescription(`It's currently ${interaction.user}'s turn.`);
      await reply.edit({
          content: `${interaction.user} it's your turn now.`,
          embeds: [embed],
      });
  
      const initialUserInteraction = await reply.awaitMessageComponent({
          filter: (i) => i.user.id === interaction.user.id,
          
      }).catch(async (error) => {
          embed.setDescription(`Game over buddy. ${interaction.user} did not respond in time.`);
          await reply.edit({ embeds: [embed], components: [] });
      });
  
      if (!initialUserInteraction) return;
  
      const initialUserChoice = choices.find(
          (choice) => choice.name === initialUserInteraction.customId
      );
    //   await initialUserChoice.reply({
    //     content: `You picked ${initialUserChoice.name + initialUserChoice.emoji}`,
    //     ephemeral: true,
    // });
      let result;
  
      if (targetUserChoice.beats === initialUserChoice.name) {
          result = `<@${targetUser['user'].id}> won! yay`;
      }
  
      if (initialUserChoice.beats === targetUserChoice.name) {
          result = `${interaction.user} won! yay`;
      }
  
      if (targetUserChoice.name === initialUserChoice.name) {
          result = "It was a tie!";
      }
  
      embed.setDescription(
          `<@${targetUser['user'].id}> picked ${targetUserChoice.name + targetUserChoice.emoji}\n
              ${interaction.user} picked ${initialUserChoice.name + initialUserChoice.emoji}
              \n\n${result}`
      );
  
      reply.edit({ embeds: [embed], components: [] });
    },
  
    name: "rps",
    description: "Play Rock Paper Scissors with a user.",
    options: [
      {
        name: "target-user",
        description: "The user you want to play.",
        type: ApplicationCommandOptionType.User,
        required: true,
      },
    ],
  };
  
  