const {
    Client,
    GuildMember
  } = require("discord.js");
  const db = require('../../database');
const autoresponses = require("./autoresponses");
  /**
     *
     * @param {Client} client
     * @param {GuildMember} member
     */
  module.exports = {
    name: 'settings',
    description: 'list of settings!',
    // devOnly: Boolean,
    // testOnly: Boolean,
    // options: Object[],
    // deleted: Boolean,
  
    callback: async (client, interaction) => {
      let guild = interaction.guild;
      if (!guild) return;
      await interaction.deferReply();
      let findGuildForeignKey = await db.findOne(
        "dc_guilds",
        "guild_id",
        guild.id
      );
      const reply = await interaction.fetchReply();
      const setting = await db.findOne('server_settings', 'dc_guild_id', findGuildForeignKey.id)
      let list = '';
      list += setting.auto_responses_enable == 0 ?'autoresponses: ❌\n': 'autoresponses: ✔\n';
      list += setting.quotes_enabled == 0 ?'quotes: ❌\n': 'quotes: ✔\n';
      list += setting.pickups_enabled == 0 ?'pickups: ❌\n': 'pickups: ✔\n';
      list += setting.welcome_messages_enabled == 0 ?'welcome messages: ❌\n': 'welcome messages: ✔\n';
      list += setting.mod_message_channels_enabled == 0 ?'mod message channels: ❌\n': 'mod message channels: ✔\n';
      list += setting.blacklist_enabled == 0 ?'blacklist: ❌\n': 'blacklist: ✔\n';
      list += setting.auto_roles_enabled == 0 ?'auto roles: ❌\n': 'auto roles: ✔\n';
      interaction.editReply(
        `list of settings:\n${list}`
      );
    },
  };