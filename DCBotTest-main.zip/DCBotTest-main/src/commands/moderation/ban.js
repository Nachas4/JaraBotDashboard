const {
  Client,
  Interaction,
  ApplicationCommandOptionType,
  PermissionFlagsBits,
} = require('discord.js');

let targetChannelId = '1237138253988233318'; // Replace this with your specific channel ID

module.exports = {
  /**
   *
   * @param {Client} client
   * @param {Interaction} interaction
   */

  callback: async (client, interaction) => {
    // const db = require('../../database');
    // let guildid = interaction.guild_id;
    // let dc_guild_id = await db.findOne("dc_guilds", "guild_id", guildid).guild_id;
    // targetChannelId = await db.findOne("mod_message_channels", "dc_guild_id", dc_guild_id).ban;
    const targetUserId = interaction.options.get('target-user').value;
    const reason =
      interaction.options.get('reason')?.value || 'No reason provided';
    const targetChannel = interaction.guild.channels.cache.get(targetChannelId);

    if (!targetChannel) {
      await interaction.reply({
        content: 'Could not find the target text channel.',
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    const targetUser = await interaction.guild.members.fetch(targetUserId);

    if (!targetUser) {
      await interaction.followUp({
        content: "That user doesn't exist in this server.",
        ephemeral: true,
      });
      return;
    }

    if (targetUser.id === interaction.guild.ownerId) {
      await interaction.followUp({
        content: "You can't ban that user because they're the server owner.",
        ephemeral: true,
      });
      return;
    }

    const targetUserRolePosition = targetUser.roles.highest.position; // Highest role of the target user
    const requestUserRolePosition = interaction.member.roles.highest.position; // Highest role of the user running the cmd
    const botRolePosition = interaction.guild.members.me.roles.highest.position; // Highest role of the bot

    if (targetUserRolePosition >= requestUserRolePosition) {
      await interaction.followUp({
        content:
          "You can't ban that user because they have the same/higher role than you.",
        ephemeral: true,
      });
      return;
    }

    if (targetUserRolePosition >= botRolePosition) {
      await interaction.followUp({
        content:
          "I can't ban that user because they have the same/higher role than me.",
        ephemeral: true,
      });
      return;
    }

    // Ban the targetUser
    try {
      await targetUser.ban({ reason });
      await interaction.followUp({
        content: 'User successfully banned.',
        ephemeral: true,
      });
      await targetChannel.send(
        `${targetUser} was banned by ${interaction.user}\nReason: ${reason}`
      );
    } catch (error) {
      console.log(`There was an error when banning: ${error}`);
      await interaction.followUp({
        content: 'There was an error banning the user.',
        ephemeral: true,
      });
    }
  },

  name: 'ban',
  description: 'Bans a member from this server.',
  options: [
    {
      name: 'target-user',
      description: 'The user you want to ban.',
      type: ApplicationCommandOptionType.Mentionable,
      required: true,
    },
    {
      name: 'reason',
      description: 'The reason you want to ban.',
      type: ApplicationCommandOptionType.String,
    },
  ],
  permissionsRequired: [PermissionFlagsBits.BanMembers],
  botPermissions: [PermissionFlagsBits.BanMembers],
};
