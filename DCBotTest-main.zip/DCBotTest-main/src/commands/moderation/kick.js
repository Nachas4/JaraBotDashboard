const {
  Client,
  Interaction,
  ApplicationCommandOptionType,
  PermissionFlagsBits,
} = require('discord.js');

let specificChannelId = '1237138463212568666'; // Replace with your specific channel ID

module.exports = {
  /**
   *
   * @param {Client} client
   * @param {Interaction} interaction
   */

  callback: async (client, interaction) => {
    // const db = require('../../database');
    // let guildid = interaction.guild_id;
    // let dc_guild_id = await db.findOne("dc_guilds", "guild_id", guildid).guild_id;
    // specificChannelId = await db.findOne("mod_message_channels", "dc_guild_id", dc_guild_id).kick;
    const targetUserId = interaction.options.get('target-user').value;
    const reason =
      interaction.options.get('reason')?.value || 'No reason provided';
    
    const specificChannel = interaction.guild.channels.cache.get(specificChannelId);

    if (!specificChannel) {
      await interaction.reply({
        content: 'Could not find the target text channel.',
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    const targetUser = await interaction.guild.members.fetch(targetUserId);

    if (!targetUser) {
      await interaction.followUp({
        content: "That user doesn't exist in this server.",
        ephemeral: true,
      });
      return;
    }

    if (targetUser.id === interaction.guild.ownerId) {
      await interaction.followUp({
        content: "You can't kick that user because they're the server owner.",
        ephemeral: true,
      });
      return;
    }

    const targetUserRolePosition = targetUser.roles.highest.position; // Highest role of the target user
    const requestUserRolePosition = interaction.member.roles.highest.position; // Highest role of the user running the cmd
    const botRolePosition = interaction.guild.members.me.roles.highest.position; // Highest role of the bot

    if (targetUserRolePosition >= requestUserRolePosition) {
      await interaction.followUp({
        content: "You can't kick that user because they have the same/higher role than you.",
        ephemeral: true,
      });
      return;
    }

    if (targetUserRolePosition >= botRolePosition) {
      await interaction.followUp({
        content: "I can't kick that user because they have the same/higher role than me.",
        ephemeral: true,
      });
      return;
    }

    // Kick the targetUser
    try {
      await targetUser.kick({ reason });
      const message = `${targetUser} was kicked by ${interaction.user}\nReason: ${reason}`;

      // Send the message directly to the specific channel
      await specificChannel.send(message);

      await interaction.followUp({
        content: 'User successfully kicked.',
        ephemeral: true,
      });
    } catch (error) {
      console.log(`There was an error when kicking: ${error}`);
      await interaction.followUp({
        content: 'There was an error kicking the user.',
        ephemeral: true,
      });
    }
  },

  name: 'kick',
  description: 'Kicks a member from this server.',
  options: [
    {
      name: 'target-user',
      description: 'The user you want to kick.',
      type: ApplicationCommandOptionType.Mentionable,
      required: true,
    },
    {
      name: 'reason',
      description: 'The reason you want to kick.',
      type: ApplicationCommandOptionType.String,
    },
  ],
  permissionsRequired: [PermissionFlagsBits.KickMembers],
  botPermissions: [PermissionFlagsBits.KickMembers],
};
