const {
  Client,
  Interaction,
  ApplicationCommandOptionType,
  PermissionFlagsBits,
} = require('discord.js');
const ms = require('ms');

const specificChannelId = '1237138631035191317'; // Replace with your specific channel ID

module.exports = {
  /**
   *
   * @param {Client} client
   * @param {Interaction} interaction
   */

  callback: async (client, interaction) => {
    // const db = require('../../database');
    // let guildid = interaction.guild_id;
    // let dc_guild_id = await db.findOne("dc_guilds", "guild_id", guildid).guild_id;
    // specificChannelId = await db.findOne("mod_message_channels", "dc_guild_id", dc_guild_id).mute;
    const mentionable = interaction.options.get('target-user').value;
    const duration = interaction.options.get('duration').value; // 1d, 1 day, 1s 5s, 5m
    const reason =
      interaction.options.get('reason')?.value || 'No reason provided';

    await interaction.deferReply({ ephemeral: true });

    const targetUser = await interaction.guild.members.fetch(mentionable);
    if (!targetUser) {
      await interaction.followUp({
        content: "That user doesn't exist in this server.",
        ephemeral: true,
      });
      return;
    }

    if (targetUser.user.bot) {
      await interaction.followUp({
        content: "I can't mute a bot.",
        ephemeral: true,
      });
      return;
    }

    const msDuration = ms(duration);
    if (isNaN(msDuration)) {
      await interaction.followUp({
        content: 'Please provide a valid mute duration.',
        ephemeral: true,
      });
      return;
    }

    if (msDuration < 5000 || msDuration > 2.419e9) {
      await interaction.followUp({
        content:
          'Mute duration cannot be less than 5 seconds or more than 28 days.',
        ephemeral: true,
      });
      return;
    }

    const targetUserRolePosition = targetUser.roles.highest.position; // Highest role of the target user
    const requestUserRolePosition = interaction.member.roles.highest.position; // Highest role of the user running the cmd
    const botRolePosition = interaction.guild.members.me.roles.highest.position; // Highest role of the bot

    if (targetUserRolePosition >= requestUserRolePosition) {
      await interaction.followUp({
        content:
          "You can't mute that user because they have the same/higher role than you.",
        ephemeral: true,
      });
      return;
    }

    if (targetUserRolePosition >= botRolePosition) {
      await interaction.followUp({
        content:
          "I can't mute that user because they have the same/higher role than me.",
        ephemeral: true,
      });
      return;
    }

    // Mute the user
    try {
      const { default: prettyMs } = await import('pretty-ms');

      let message;
      const executorUser = interaction.user; // The user executing the command

      if (targetUser.isCommunicationDisabled()) {
        await targetUser.MuteMembers(msDuration, reason);
        message = `${targetUser}'s mute has been updated to ${prettyMs(
          msDuration,
          { verbose: true }
        )}\nReason: ${reason}\nMuted by: ${executorUser}`;
      } else {
        await targetUser.timeout(msDuration, reason);
        message = `${targetUser} was muted for ${prettyMs(msDuration, {
          verbose: true,
        })}.\nReason: ${reason}\nMuted by: ${executorUser}`;
      }

      // Send the message directly to the specific channel
      const specificChannel = client.channels.cache.get(specificChannelId);
      if (specificChannel) {
        await specificChannel.send(message);
      } else {
        console.log(`Channel with ID ${specificChannelId} not found.`);
      }

      await interaction.followUp({
        content: 'User muted successfully.',
        ephemeral: true,
      });
    } catch (error) {
      console.log(`There was an error: ${error}`);
      await interaction.followUp({
        content: 'An error occurred while muting the user.',
        ephemeral: true,
      });
    }
  },

  name: 'mute',
  description: 'Mute a user.',
  options: [
    {
      name: 'target-user',
      description: 'The user you want to mute.',
      type: ApplicationCommandOptionType.Mentionable,
      required: true,
    },
    {
      name: 'duration',
      description: 'Mute duration (30m, 1h, 1 day).',
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: 'reason',
      description: 'The reason for the mute.',
      type: ApplicationCommandOptionType.String,
    },
  ],
  permissionsRequired: [PermissionFlagsBits.MuteMembers],
  botPermissions: [PermissionFlagsBits.MuteMembers],
};
