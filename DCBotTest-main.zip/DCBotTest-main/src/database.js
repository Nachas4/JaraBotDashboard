var mysql = require("mysql");

var con = mysql.createPool({
	host: "localhost",
	user: "root",
	password: "",
	database: "jarabot",
});

// const db = require("./db");


// async function main() {

//     await db.deleteAll('users');

// 	await db.insertMany("users", [
// 		{
// 			name: "Jon",
// 			username: "garfield",
// 			password: "234234",
// 		},
// 	]);

// 	/* INSERT Many*/
// 	await db.insertMany("users", [
// 		{
// 			name: "Jon",
// 			username: "4322",
// 			password: "3423",
// 		},
//         {
// 			name: "Jonetab",
// 			username: "tab",
// 			password: "64545636",
// 		},
// 		{
// 			name: "Dred",
// 			username: "meatTower",
// 			password: "5342123",
// 		},
// 		{ 
// 			name: "Claudia",
// 			username: "queen",
// 			password: "756234",
// 		},
// 	]);

// 	// /* FIND */
// 	const data = await db.findMany("users", "name", "Jon");
// 	console.log("data :>> ", data);

// 	// /* FIND ONE */
// 	const data2 = await db.findOne("users", "name", "Dred");
// 	console.log("data2 :>> ", data2);

// 	/* UPDATE */
// 	await db.updateMany("users", "name", "Jonetab", {
// 		username: "alien",
// 	});

// 	/* DELETE */
// 	await db.deleteMany("users", "username", "queen");

//     await db.dropTable("asd");
// }

// main().catch(console.error);

//finds Multiple record in the database and returns it as array object
function findMany(table, field, value) {
	const query = `SELECT * FROM ${table} WHERE ${field} = "${value}"`;
    return new Promise((resolve, reject) => {
		con.getConnection((err, connection) => {
			if (err) reject(err);
			connection.query(query, (err,result) => {
				if (err) reject(err);
                resolve(result);
			});
            connection.release();
		});
	});

}

//finds Multiple record in the database but returns only the first result as object (for ease of use)
function findOne(table, field, value) {
	const query = `SELECT * FROM ${table} WHERE ${field} = "${value}"`;
    return new Promise((resolve, reject) => {
		con.getConnection((err, connection) => {
			if (err) reject(err);
			connection.query(query, (err,result) => {
				if (err) reject(err);
                resolve(result[0]);
			});
            connection.release();
		});
	});

}

function insertMany(table, objectArray) {
	return new Promise((resolve, reject) => {
		con.getConnection((err, connection) => {
			if (err) reject(err);
			for (const object of objectArray) {
				connection.query(`INSERT INTO ${table} SET ?`, object, (err) => {
					if (err) reject(err);
				});
			}
			connection.release();
			resolve(console.log("Records successfully inserted"));
		});
	});
}

function updateMany(table, field, value, object) {
    return new Promise((resolve, reject) => {
		con.getConnection((err, connection) => {
			if (err) reject(err);
			connection.query(`UPDATE ${table} SET ? WHERE ${field} = "${value}"`,object, (err) => {
				if (err) reject(err);
                resolve(console.log("Record(s) successfully  updated"));
			});
            connection.release();
		});
	});
}

function deleteMany(table, field, value) {
    const query =`DELETE FROM ${table} WHERE ${field} = "${value}"`;

    return new Promise((resolve, reject) => {
		con.getConnection((err, connection) => {
			if (err) reject(err);
			connection.query(query, (err) => {
				if (err) reject(err);
                resolve(console.log("Record(s) successfully deleted"));
			});
            connection.release();
		});
	});
}

function deleteAll(table) {
    const query =`DELETE FROM ${table}`;

    return new Promise((resolve, reject) => {
		con.getConnection((err, connection) => {
			if (err) reject(err);
			connection.query(query, (err) => {
				if (err) reject(err);
                resolve(console.log(`${table} records successfully deleted`));
			});
            connection.release();
		});
	});
}

function dropTable(table) {
    return new Promise((resolve, reject) => {
		con.getConnection((err, connection) => {
			if (err) reject(err);
			connection.query(`DROP TABLE ${table}`, (err) => {
				if (err) reject(err);
                resolve(console.log(`${table} table successfully deleted`));
			});
            connection.release();
		});
	});
}

module.exports = {
	findMany,
	findOne,
	insertMany,
	updateMany,
	deleteMany,
	deleteAll,
	dropTable,
};
