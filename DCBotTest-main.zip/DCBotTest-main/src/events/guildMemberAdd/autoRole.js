const { Client, GuildMember } = require('discord.js');
const databaseQuery = require("../../database");

/**
 *
 * @param {Client} client
 * @param {GuildMember} member
 */
module.exports = async (client, member) => {
  try {
    let guild = member.guild;
    if (!guild) return;
    let findGuildForeignKey = await databaseQuery.findOne('dc_guilds', 'guild_id', process.env.GUILD_ID);
    // console.log(findGuildForeignKey);
    let autoRole = await databaseQuery.findMany('auto_roles', 'dc_guild_id', findGuildForeignKey.id);
    if (!autoRole) return;
    console.log(autoRole);

    for(let role of autoRole){
      await member.roles.add(role.role_id);
    }
  } catch (error) {
    console.log(`Error giving role automatically: ${error}`);
  }
};