const {
    Client,
    GuildMember,
    AttachmentBuilder,
    EmbedBuilder,
  } = require("discord.js");
  const databaseQuery = require("../../database");
  const fs = require("fs");
  
  /**
   *
   * @param {Client} client
   * @param {GuildMember} member
   */
  
  module.exports = async (client, member) => {
    try {
      let guild = member.guild;
      if (!guild) return;
      let findGuildForeignKey = await databaseQuery.findOne(
        "dc_guilds",
        "guild_id",
        guild.id
      );
  
      let welcomeM = await databaseQuery.findOne(
        "welcome_messages",
        "dc_guild_id",
        findGuildForeignKey.id
      );
  
      if (!welcomeM) return;
      const channel = member.guild.channels.cache.get(welcomeM.channel_id);
      console.log(channel);
  
      const attachment = new AttachmentBuilder(`C:\\Users\\user\\Downloads\\${welcomeM.bg_image}`);
  
      if (channel) {
        const welcomeEmbed = new EmbedBuilder()
          .setTitle(welcomeM.message)
          .setImage(`attachment://${welcomeM.bg_image}`);
  
        channel.send({ embeds: [welcomeEmbed], files: [attachment] });
        console.log('welcome message js');
      } else {
        console.error("Welcome channel not found. Please check the channel ID.");
      }
    } catch (error) {
      console.log(`Error when greeting the user automatically: ${error}`);
    }
  };