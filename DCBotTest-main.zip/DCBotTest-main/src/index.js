require("dotenv").config(); //npm install dotenv
var mysql = require("mysql"); //npm install mysql
const {Client,IntentsBitField,EmbedBuilder,messageLink,ActivityType, ChatInputCommandInteraction, REST, Routes } = require("discord.js"); //npm install discord.js
const databaseQuery = require("./database");
const eventHandler = require("./handlers/eventHandler");
const autoRole = require("./events/guildMemberAdd/autoRole");

const rest = new REST().setToken("MTIxNDI1NzgzODEzNDkyNzQzMA.GUMi3R.cMOUENHCvHHWvw_1BXZ7XOwntDO_8SP18BN5Nc");

// // for global commands
// rest.put(Routes.applicationCommands('1214257838134927430'), { body: [] })
// 	.then(() => console.log('Successfully deleted all application commands.'))
// 	.catch(console.error);

const client = new Client({
  intents: [
    IntentsBitField.Flags.Guilds,
    IntentsBitField.Flags.GuildMembers,
    IntentsBitField.Flags.GuildMessages,
    IntentsBitField.Flags.MessageContent,
  ],
});

eventHandler(client);
// client.on ( 'ready', (c) => {
//  console.log(`${c.user.tag} is online.`);
//  });

//BaseStatuses
let status = [
  {
    name: "Black1200",
    type: ActivityType.Streaming,
    url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
  },
  {
    name: "Team Fortress 2",
  },
  {
    name: "CaseOh",
    type: ActivityType.Watching,
  },
  {
    name: "Spider-Man Theme (original)",
    type: ActivityType.Listening,
  },
];

//ActivityStatusChanger
setInterval(() => {
  let random = Math.floor(Math.random() * status.length);
  client.user.setActivity(status[random]);
}, 25000);

client.on('error', (error) => {
  console.error('Client encountered an error:', error);
});

//Blacklist
const triggeredUsers = new Set();
const specificChannelId = '1237138773951910000'; // Replace with your desired channel ID
client.on('messageCreate', message => {
     // const db = require('../../database');
    // let guildid = interaction.guild_id;
    // let dc_guild_id = await db.findOne("dc_guilds", "guild_id", guildid).guild_id;
    // specificChannelId = await db.findOne("mod_message_channels", "dc_guild_id", dc_guild_id).blacklist;

  // Ensure that the bot doesn't respond to messages from itself
  if (message.author.bot) return;

  let blacklisted = ['Kill', 'Die', 'Hurt'];
  let foundInText = false;
  let usedWord = '';

  for (let i in blacklisted) {
    if (message.content.toLowerCase().includes(blacklisted[i].toLowerCase())) {
      foundInText = true;
      usedWord = blacklisted[i]; // Capture the offending word
      break; // Exit the loop once a blacklisted word is found
    }
  }

  if (foundInText && !triggeredUsers.has(message.author.id)) {
    triggeredUsers.add(message.author.id);

    message.delete()
      .then(() => {
        client.channels.fetch(specificChannelId)
          .then(specificChannel => {
            if (specificChannel && specificChannel.isTextBased()) {
              specificChannel.send(`${message.author} used a blacklisted word: "${usedWord}", Shame on you! :(`)
                .then(() => {
                  setTimeout(() => {
                    triggeredUsers.delete(message.author.id);
                  }, 5000); // 5-second cooldown per user
                })
                .catch(console.error);
            } else {
              console.error('Channel is not a text channel or is undefined.');
            }
          })
          .catch(err => {
            console.error(`Error fetching the channel: ${err}`);
          });
      })
      .catch(console.error);
  }
});

//BasicInteraction 1
// client.on('messageCreate', (message) => {
//    if (message.author.bot) {
//        return;
//    }

// if (message.content === "hello") {
//    message.reply('Heyho!');
// }
// else {
  //    message.reply('Please say hello first, dont be rude!');
// }
// });

//BasicInteraction 2
// client.on("interactionCreate", (interaction) => {
//   if (!interaction.isChatInputCommand()) return;

  // if (interaction.commandName === 'hey')
  // {
  //   interaction.reply('hey!');
  // }

  // if (interaction.commandName === 'ping')
  // {
  //   interaction.reply('Pong!');
  // }

  // if (interaction.commandName === 'add')
  // {
  //   const num1 = interaction.options.get('first-number').value;
  //   const num2 = interaction.options.get('second-number').value;

  //  interaction.reply(`The sum is ${num1 + num2}`);
  // }
  
  //Embed
//   if (interaction.commandName === "embed") {
//     const embed = new EmbedBuilder()
//       .setTitle("Embed title")
//       .setDescription("This is an embed description")
//       .setColor("Random")
//       .addFields(
//         {
//           name: "Field title",
//           value: "Some random value",
//           inline: true,
//         },
//         {
//           name: "2nd Field title",
//           value: "Some random value",
//           inline: true,
//         }
//       );

//       interaction.reply({ embeds: [embed] });
//   }
// });

//Embed
// client.on("messageCreate", (message) => {
//   if (message.content === "embed") {
//     const embed = new EmbedBuilder()
//     .setTitle("Embed title")
//       .setDescription("This is an embed description")
//       .setColor("Random")
//       .addFields(
//         {
//           name: "Field title",
//           value: "Some random value",
//           inline: true,
//         },
//         {
//           name: "2nd Field title",
//           value: "Some random value",
//           inline: true,
//         }
//       );

//     message.channel.send({ embeds: [embed] });
//   }
// });

//Roles
// client.on("interactionCreate", async (interaction) => {
//   try {
//     if (!interaction.isButton()) return;
//     await interaction.deferReply({ ephemeral: true });

//     const role = interaction.guild.roles.cache.get(interaction.customId);
//     if (!role) {
//       interaction.editReply({
//         content: "I couldn't find that role",
//       });
//       return;
//     }
//     const hasRole = interaction.member.roles.cache.has(role.id);

//     if (hasRole) {
//       await interaction.member.roles.remove(role);
//       await interaction.editReply(`The role ${role} has been removed.`);
//       return;
//     }
    
//     await interaction.member.roles.add(role);
//     await interaction.editReply(`The role ${role} has been added.`);
//   } catch (error) {
//     console.log(error);
//   }
// });

const autorole = require('./events/guildMemberAdd/autoRole');
const welcome = require('./events/guildMemberAdd/welcome');
client.on('guildMemberAdd', async member => {
  try {
      await autoRole.autorole(client, member);
      await welcome.WelcomeM(client, member);
      console.log('member join');
  } catch (error) {
      console.log(error);
  }
});

// Login to Discord with your client's token.
client.login(process.env.TOKEN);