require('dotenv').config(); // npm install dotenv
const { Client, IntentsBitField, EmbedBuilder, messageLink, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js'); // npm install discord.js

const client = new Client({
    intents: [
        IntentsBitField.Flags.Guilds,        
        IntentsBitField.Flags.GuildMembers,
        IntentsBitField.Flags.GuildMessages,
        IntentsBitField.Flags.MessageContent,        
    ],
});

const roles = [
{
    id: '1214698807590395924',
    label: 'Bence'
},
{
    id: '1214698906697596998',
    label: 'Matyi'
},
{
    id: '1214698966256721930',
    label: 'Gyula'
},

]

 client.on ( 'ready', async (c) => {
 try {
    const channel = await client.channels.cache.get('1212059909491916822');
    if (!channel) return;

    const row = new ActionRowBuilder();

    roles.forEach((role) => {
        row.components.push(
            new ButtonBuilder().setCustomId(role.id).setLabel(role.label).setStyle(ButtonStyle.Primary)
        )
    })

    await channel.send({
        content: 'Claim or remove a role below.',
        components: [row]
    });
    process.exit();
 } catch (error) {
    console.log(error);
 }
 });

client.login(process.env.TOKEN);
